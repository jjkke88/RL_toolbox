#!/usr/bin/env python
# -*- coding: utf-8 -*-


from __future__ import with_statement

import sys

if sys.version_info < (2 , 5):
    sys.exit('Python 2.5 or greater is required.')

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


setup(name='RLToolbox' ,
      version="1.0.1" ,
      description='rl toolbox' ,
      long_description="RL toolbox",
      author='wuyupei' ,
      author_email='840302039@qq.com' ,
      maintainer='wuyupei' ,
      maintainer_email='840302039@qq.com' ,
      url='https://github.com/jjkke88/RL_toolbox' ,
      packages=['RLToolbox', 'RLToolbox.agent', 'RLToolbox.algorithm', 'RLToolbox.environment', 'RLToolbox.storage', 'RLToolbox.toolbox', 'RLToolbox.experiment'] ,
      license="GPL 3.0" ,
      platforms=['any'] ,
      classifiers=[]
      )
